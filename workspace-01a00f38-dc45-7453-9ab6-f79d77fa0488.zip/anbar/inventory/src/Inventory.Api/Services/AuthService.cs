using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Inventory.Shared;
using Inventory.Shared.Dtos;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Db = Inventory.Api.Data;

namespace Inventory.Api.Services;

/// <summary>پیاده‌سازی احراز هویت JWT و مدیریت کاربران.</summary>
public class AuthService : IAuthService
{
    /// <summary>کلید امضای توکن (در محیط عملیاتی از تنظیمات/متغیر محیطی بخوانید).</summary>
    public const string JwtKey = "InventoryApp-Jwt-Secret-Key-2026-!@#$%-Very-Long-Key-For-HS256";
    public const string JwtIssuer = "InventoryApp";

    private readonly Db.AppDbContext _db;
    private readonly IInventoryService _inventory;

    public AuthService(Db.AppDbContext db, IInventoryService inventory)
    {
        _db = db;
        _inventory = inventory;
    }

    // ---------------- رمزنگاری ----------------

    public static string HashPassword(string password)
    {
        // PBKDF2 با نمک تصادفی
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 100_000, HashAlgorithmName.SHA256, 32);
        return $"{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    public static bool VerifyPassword(string password, string stored)
    {
        var parts = stored.Split('.', 2);
        if (parts.Length != 2) return false;
        var salt = Convert.FromBase64String(parts[0]);
        var expected = Convert.FromBase64String(parts[1]);
        var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, 100_000, HashAlgorithmName.SHA256, 32);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }

    // ---------------- ورود ----------------

    public async Task<LoginResponse?> LoginAsync(LoginRequest request)
    {
        var username = (request.Username ?? "").Trim();
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Username == username && u.IsActive);
        if (user is null || !VerifyPassword(request.Password ?? "", user.PasswordHash))
            return null;

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.Username),
            new(ClaimTypes.Role, user.Role)
        };
        if (user.ReferrerId is > 0)
            claims.Add(new Claim("referrerId", user.ReferrerId.Value.ToString()));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtKey));
        var token = new JwtSecurityToken(
            issuer: JwtIssuer,
            audience: JwtIssuer,
            claims: claims,
            expires: DateTime.UtcNow.AddHours(12),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

        var display = user.Username;
        if (user.ReferrerId is > 0)
        {
            var r = await _db.Referrers.FindAsync(user.ReferrerId);
            if (r is not null) display = r.Name;
        }

        return new LoginResponse
        {
            Token = new JwtSecurityTokenHandler().WriteToken(token),
            Username = user.Username,
            Role = user.Role,
            ReferrerId = user.ReferrerId,
            DisplayName = display
        };
    }

    // ---------------- مدیریت کاربران ----------------

    public async Task<List<UserDto>> GetUsersAsync()
    {
        var users = await _db.Users.OrderBy(u => u.Username).ToListAsync();
        var refNames = await _db.Referrers.ToDictionaryAsync(r => r.Id, r => r.Name);
        return users.Select(u => new UserDto
        {
            Id = u.Id,
            Username = u.Username,
            Role = u.Role,
            ReferrerId = u.ReferrerId,
            ReferrerName = u.ReferrerId.HasValue && refNames.TryGetValue(u.ReferrerId.Value, out var n) ? n : null,
            IsActive = u.IsActive,
            CreatedAt = u.CreatedAt
        }).ToList();
    }

    public async Task<UserDto> SaveUserAsync(UserDto dto, bool callerIsAdmin = true)
    {
        var username = (dto.Username ?? "").Trim();
        if (string.IsNullOrWhiteSpace(username))
            throw new InvalidOperationException("نام کاربری را وارد کنید.");
        if (dto.Role is not ("Admin" or "Operator" or "Referrer"))
            throw new InvalidOperationException("نقش کاربر نامعتبر است.");
        if (dto.Role == "Referrer" && dto.ReferrerId is not > 0)
            throw new InvalidOperationException("برای کاربر معرف، معرف مرتبط را انتخاب کنید.");

        // اپراتور: هیچ عملیاتی مرتبط با نقش ادمین مجاز نیست
        if (!callerIsAdmin && dto.Role == "Admin")
            throw new InvalidOperationException("اپراتور نمی‌تواند کاربر با نقش «مدیر» ایجاد کند یا نقش کاربری را به مدیر تغییر دهد.");

        var dup = await _db.Users.AnyAsync(u => u.Username == username && u.Id != dto.Id);
        if (dup) throw new InvalidOperationException("این نام کاربری قبلاً ثبت شده است.");

        Db.User entity;
        if (dto.Id == 0)
        {
            if (string.IsNullOrWhiteSpace(dto.Password))
                throw new InvalidOperationException("رمز عبور را وارد کنید.");
            entity = new Db.User { CreatedAt = DateTime.Now };
            _db.Users.Add(entity);
        }
        else
        {
            entity = await _db.Users.FindAsync(dto.Id)
                ?? throw new InvalidOperationException("کاربر یافت نشد.");

            // اپراتور نمی‌تواند کاربر ادمین موجود را ویرایش کند (نه نقش، نه رمز، نه وضعیت)
            if (!callerIsAdmin && entity.Role == "Admin")
                throw new InvalidOperationException("اپراتور اجازه ویرایش کاربران «مدیر» را ندارد.");
        }

        entity.Username = username;
        entity.Role = dto.Role;
        entity.ReferrerId = dto.Role == "Referrer" ? dto.ReferrerId : null;
        entity.IsActive = dto.IsActive;
        if (!string.IsNullOrWhiteSpace(dto.Password))
        {
            if (dto.Password.Length < 4)
                throw new InvalidOperationException("رمز عبور باید حداقل ۴ کاراکتر باشد.");
            entity.PasswordHash = HashPassword(dto.Password);
        }

        await _db.SaveChangesAsync();
        return (await GetUsersAsync()).First(u => u.Id == entity.Id);
    }

    public async Task DeleteUserAsync(int id, int currentUserId, bool callerIsAdmin = true)
    {
        if (id == currentUserId)
            throw new InvalidOperationException("نمی‌توانید حساب کاربری خودتان را حذف کنید.");
        var u = await _db.Users.FindAsync(id);
        if (u is null) return;

        // اپراتور نمی‌تواند کاربر ادمین را حذف کند
        if (!callerIsAdmin && u.Role == "Admin")
            throw new InvalidOperationException("اپراتور اجازه حذف کاربران «مدیر» را ندارد.");
        var adminCount = await _db.Users.CountAsync(x => x.Role == "Admin" && x.IsActive);
        if (u.Role == "Admin" && adminCount <= 1)
            throw new InvalidOperationException("حداقل یک مدیر فعال باید باقی بماند.");
        _db.Users.Remove(u);
        await _db.SaveChangesAsync();
    }

    public async Task ChangePasswordAsync(int userId, string currentPassword, string newPassword)
    {
        var u = await _db.Users.FindAsync(userId)
            ?? throw new InvalidOperationException("کاربر یافت نشد.");
        if (!VerifyPassword(currentPassword ?? "", u.PasswordHash))
            throw new InvalidOperationException("رمز عبور فعلی اشتباه است.");
        if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 4)
            throw new InvalidOperationException("رمز عبور جدید باید حداقل ۴ کاراکتر باشد.");
        u.PasswordHash = HashPassword(newPassword);
        await _db.SaveChangesAsync();
    }

    // ---------------- داشبورد معرف ----------------

    public async Task<ReferrerDashboard> GetReferrerDashboardAsync(int referrerId)
    {
        var referrer = await _db.Referrers.FindAsync(referrerId)
            ?? throw new InvalidOperationException("معرف یافت نشد.");

        var wallets = await _inventory.GetReferrerWalletsAsync(null, "name", false);
        var wallet = wallets.FirstOrDefault(w => w.Id == referrerId);

        var txns = await _db.Transactions
            .Where(t => t.ReferrerId == referrerId && t.Type == TransactionType.Sale)
            .OrderByDescending(t => t.Date).ThenByDescending(t => t.Id)
            .ToListAsync();

        var partyNames = await _db.Parties.ToDictionaryAsync(p => p.Id, p => p.Name);

        // پورسانت ماه جاری شمسی + آخرین فروش‌ها
        var (jy, jm, _) = PersianDate.FromGregorian(DateTime.Now);
        var monthStart = PersianDate.ToGregorian(jy, jm, 1);

        decimal monthCommission = 0;
        var recent = new List<ReferrerSaleRow>();
        foreach (var t in txns)
        {
            var order = await _inventory.GetOrderAsync(t.Id);
            var commission = order?.CommissionAmount ?? 0;
            if (t.Date >= monthStart) monthCommission += commission;
            if (recent.Count < 8)
            {
                recent.Add(new ReferrerSaleRow
                {
                    Number = t.Number,
                    Date = t.Date,
                    CustomerName = t.PartyId.HasValue && partyNames.TryGetValue(t.PartyId.Value, out var pn) ? pn : null,
                    Amount = t.Amount,
                    Commission = commission
                });
            }
        }

        var payments = await _inventory.GetReferrerPaymentsAsync(referrerId);

        return new ReferrerDashboard
        {
            ReferrerName = referrer.Name,
            Phone = referrer.Phone,
            CanViewProducts = referrer.CanViewProducts,
            CompanyName = referrer.CompanyName,
            GoodsCommissionPercent = referrer.GoodsCommissionPercent,
            ServiceCommissionPercent = referrer.ServiceCommissionPercent,
            OrderCount = txns.Count,
            TotalSales = txns.Sum(t => t.Amount),
            TotalCommission = wallet?.TotalCommission ?? 0,
            TotalPaid = wallet?.TotalPaid ?? 0,
            WalletBalance = wallet?.WalletBalance ?? 0,
            MonthCommission = monthCommission,
            RecentSales = recent,
            RecentPayments = payments.Take(8).ToList()
        };
    }
}
