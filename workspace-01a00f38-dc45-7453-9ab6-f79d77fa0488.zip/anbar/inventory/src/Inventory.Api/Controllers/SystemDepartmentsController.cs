using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Api.Data;

namespace Inventory.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SystemDepartmentsController : ControllerBase
{
    private readonly AppDbContext _db;
    public SystemDepartmentsController(AppDbContext db) => _db = db;

    [HttpGet] public async Task<ActionResult> Get() => Ok(await _db.SystemDepartments.ToListAsync());
    [HttpGet("{id}")] public async Task<ActionResult> Get(int id) => Ok(await _db.SystemDepartments.FirstOrDefaultAsync(x => x.Id == id));
    [HttpPost] public async Task<ActionResult> Post([FromBody] SystemDepartment d) { _db.SystemDepartments.Add(d); await _db.SaveChangesAsync(); return Ok(new { id = d.Id }); }
}
