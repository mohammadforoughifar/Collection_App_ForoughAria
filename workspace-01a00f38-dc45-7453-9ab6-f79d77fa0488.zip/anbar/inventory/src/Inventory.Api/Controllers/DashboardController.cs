using Inventory.Api.Services;
using Inventory.Shared.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Inventory.Api.Controllers;

/// <summary>آمار داشبورد.</summary>
[Route("api/dashboard")]
public class DashboardController : ApiControllerBase
{
    private readonly IInventoryService _service;

    public DashboardController(IInventoryService service) => _service = service;

    /// <summary>خلاصه آمار کل سیستم.</summary>
    [HttpGet]
    public async Task<ActionResult<DashboardSummary>> Get()
        => Ok(await _service.GetDashboardAsync());

    /// <summary>آخرین فعالیت‌ها.</summary>
    [HttpGet("recent")]
    public async Task<ActionResult<List<RecentActivity>>> GetRecent([FromQuery] int count = 8)
        => Ok(await _service.GetRecentAsync(count));

    /// <summary>داشبورد مدیریتی: فروش/سود دوره‌ای + بدهکاران + چک‌های امروز — فقط مدیر.</summary>
    [HttpGet("admin")]
    [Microsoft.AspNetCore.Authorization.Authorize(Roles = "Admin")]
    public async Task<ActionResult<AdminDashboard>> GetAdmin()
        => Ok(await _service.GetAdminDashboardAsync());

    /// <summary>پاس کردن چک — فقط مدیر.</summary>
    [HttpPost("cheques/{id:int}/clear")]
    [Microsoft.AspNetCore.Authorization.Authorize(Roles = "Admin")]
    public async Task<IActionResult> ClearCheque(int id)
    {
        await _service.ClearChequeAsync(id);
        return Ok(new { ok = true });
    }

    /// <summary>ثبت پرداخت قسط.</summary>
    [HttpPost("installments/{id:int}/pay")]
    public async Task<IActionResult> PayInstallment(int id)
    {
        await _service.PayInstallmentAsync(id);
        return Ok(new { ok = true });
    }

    /// <summary>تسویه سند نسیه.</summary>
    [HttpPost("credits/{transactionId:int}/settle")]
    public async Task<IActionResult> SettleCredit(int transactionId, [FromQuery] decimal amount)
    {
        await _service.SettleCreditAsync(transactionId, amount);
        return Ok(new { ok = true });
    }
}

/// <summary>بررسی سلامت سرویس.</summary>
[Route("api/health")]
[Microsoft.AspNetCore.Authorization.AllowAnonymous]
public class HealthController : ApiControllerBase
{
    [HttpGet]
    public IActionResult Get() => Ok(new { status = "ok", time = DateTime.Now });
}
