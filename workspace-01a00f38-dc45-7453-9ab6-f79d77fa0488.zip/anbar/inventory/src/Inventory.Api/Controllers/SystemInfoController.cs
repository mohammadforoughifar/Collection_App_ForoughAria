using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Api.Data;

namespace Inventory.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SystemInfoController : ControllerBase
{
    private readonly AppDbContext _db;
    public SystemInfoController(AppDbContext db) => _db = db;

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] SystemInfo info)
    {
        info.ReceivedAt = DateTime.Now;
        _db.SystemInfos.Add(info);
        await _db.SaveChangesAsync();
        return Ok(new { id = info.Id, agent = info.AgentId, received = info.ReceivedAt });
    }

    [HttpGet]
    public async Task<IActionResult> Get() => Ok(await _db.SystemInfos.ToListAsync());

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        return item == null ? NotFound() : Ok(item);
    }

    [HttpPost("assign-user")]
    public Task<IActionResult> AssignUser([FromBody] SystemInfoUserLink link)
    {
        return Task.FromResult<IActionResult>(Ok(new { linked = true, userId = link?.UserId, systemInfoId = link?.SystemInfoId }));
    }

    [HttpPost("approve/{id}")]
    public async Task<IActionResult> Approve(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound();
        item.IsApproved = true;
        await _db.SaveChangesAsync();
        return Ok(new { id, approved = true });
    }
}

public class SystemInfoUserLink
{
    public int SystemInfoId { get; set; }
    public int UserId { get; set; }
}
