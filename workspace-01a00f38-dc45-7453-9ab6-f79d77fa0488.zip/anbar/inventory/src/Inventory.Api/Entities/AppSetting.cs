using System.ComponentModel.DataAnnotations;
using Inventory.Shared;
namespace Inventory.Api.Data;
public class AppSetting
{
    public int Id { get; set; }
    [MaxLength(20)] public string CostingMethod { get; set; } = "Average";
    public bool AllowNegativeStock { get; set; } = false;
}