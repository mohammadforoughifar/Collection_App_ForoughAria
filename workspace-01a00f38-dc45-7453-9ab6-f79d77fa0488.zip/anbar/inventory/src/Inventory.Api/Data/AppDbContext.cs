using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<AppSetting> AppSettings => Set<AppSetting>();
    public DbSet<Referrer> Referrers => Set<Referrer>();
    public DbSet<ReferrerPayment> ReferrerPayments => Set<ReferrerPayment>();
    public DbSet<ProductCategory> ProductCategories => Set<ProductCategory>();
    public DbSet<MeasureUnit> MeasureUnits => Set<MeasureUnit>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Warehouse> Warehouses => Set<Warehouse>();
    public DbSet<Party> Parties => Set<Party>();
    public DbSet<Stock> Stocks => Set<Stock>();
    public DbSet<Transaction> Transactions => Set<Transaction>();
    public DbSet<TransactionLine> TransactionLines => Set<TransactionLine>();
    public DbSet<ExpenseCategory> ExpenseCategories => Set<ExpenseCategory>();
    public DbSet<Expense> Expenses => Set<Expense>();
    public DbSet<Cheque> Cheques => Set<Cheque>();
    public DbSet<InstallmentLine> Installments => Set<InstallmentLine>();
    public DbSet<Technician> Technicians => Set<Technician>();
    public DbSet<RepairOrder> RepairOrders => Set<RepairOrder>();
    public DbSet<RepairItem> RepairItems => Set<RepairItem>();
    public DbSet<SystemInfo> SystemInfos => Set<SystemInfo>();
    public DbSet<SystemCompany> SystemCompanies => Set<SystemCompany>();
    public DbSet<SystemDepartment> SystemDepartments => Set<SystemDepartment>();
    public DbSet<SystemUser> SystemUsers => Set<SystemUser>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        base.OnModelCreating(mb);

        mb.Entity<User>().HasIndex(u => u.Username).IsUnique();
        mb.Entity<ProductCategory>().HasIndex(c => c.Name).IsUnique();
        mb.Entity<MeasureUnit>().HasIndex(u => u.Name).IsUnique();
        mb.Entity<Stock>().HasIndex(s => new { s.WarehouseId, s.ProductId }).IsUnique();
        mb.Entity<Product>().HasIndex(p => p.Code).IsUnique();
        mb.Entity<Transaction>().HasIndex(t => t.Type);
        mb.Entity<Transaction>().HasIndex(t => t.Date);
        mb.Entity<TransactionLine>().HasIndex(l => l.ProductId);

        // ---------- دقت صریح اعداد اعشاری برای SQL Server ----------
        // قیمت‌ها و مبالغ: 2 رقم اعشار
        mb.Entity<Product>().Property(p => p.SalePrice).HasPrecision(18, 2);
        mb.Entity<Product>().Property(p => p.PurchasePrice).HasPrecision(18, 2);
        mb.Entity<Stock>().Property(s => s.AvgCost).HasPrecision(18, 4);
        mb.Entity<Transaction>().Property(t => t.Amount).HasPrecision(18, 2);
        mb.Entity<TransactionLine>().Property(l => l.Price).HasPrecision(18, 2);

        // مقادیر (موجودی/مقدار) با 3 رقم اعشار
        mb.Entity<Product>().Property(p => p.ReorderPoint).HasPrecision(18, 3);
        mb.Entity<Product>().Property(p => p.MaxStock).HasPrecision(18, 3);
        mb.Entity<Stock>().Property(s => s.Quantity).HasPrecision(18, 3);
        mb.Entity<TransactionLine>().Property(l => l.Quantity).HasPrecision(18, 3);
        mb.Entity<Referrer>().Property(r => r.GoodsCommissionPercent).HasPrecision(5, 2);
        mb.Entity<Referrer>().Property(r => r.ServiceCommissionPercent).HasPrecision(5, 2);
        mb.Entity<ReferrerPayment>().Property(p => p.Amount).HasPrecision(18, 2);
        mb.Entity<ReferrerPayment>().HasIndex(p => p.ReferrerId);

        // ---------- هزینه‌ها ----------
        mb.Entity<ExpenseCategory>().HasIndex(c => c.Name).IsUnique();
        mb.Entity<Expense>().Property(e => e.Amount).HasPrecision(18, 2);
        mb.Entity<Expense>().HasIndex(e => e.Date);
        mb.Entity<Expense>().HasIndex(e => e.CategoryId);

        // ---------- پرداخت فروش: چک و اقساط ----------
        mb.Entity<Transaction>().Property(t => t.SettledAmount).HasPrecision(18, 2);
        mb.Entity<Transaction>().Property(t => t.CashAmount).HasPrecision(18, 2);
        mb.Entity<Cheque>().Property(c => c.Amount).HasPrecision(18, 2);
        mb.Entity<Cheque>().HasIndex(c => c.DueDate);
        mb.Entity<Cheque>().HasIndex(c => c.IsCleared);
        mb.Entity<InstallmentLine>().Property(i => i.Amount).HasPrecision(18, 2);
        mb.Entity<InstallmentLine>().HasIndex(i => i.DueDate);
        mb.Entity<Transaction>()
            .HasMany(t => t.Cheques)
            .WithOne()
            .HasForeignKey(c => c.TransactionId)
            .OnDelete(DeleteBehavior.Cascade);
        mb.Entity<Transaction>()
            .HasMany(t => t.Installments)
            .WithOne()
            .HasForeignKey(i => i.TransactionId)
            .OnDelete(DeleteBehavior.Cascade);

        // ---------- تعمیرات ----------
        mb.Entity<RepairOrder>().HasIndex(r => r.Status);
        mb.Entity<RepairOrder>().HasIndex(r => r.PartyId);
        mb.Entity<RepairOrder>().HasIndex(r => r.TechnicianId);
        mb.Entity<RepairOrder>().Property(r => r.QuotedPrice).HasPrecision(18, 2);
        mb.Entity<RepairOrder>()
            .HasMany(r => r.Items)
            .WithOne()
            .HasForeignKey(i => i.RepairOrderId)
            .OnDelete(DeleteBehavior.Cascade);
        mb.Entity<RepairItem>().Property(i => i.Quantity).HasPrecision(18, 3);
        mb.Entity<RepairItem>().Property(i => i.Cost).HasPrecision(18, 2);
        mb.Entity<RepairItem>().Property(i => i.Price).HasPrecision(18, 2);
    }
}
