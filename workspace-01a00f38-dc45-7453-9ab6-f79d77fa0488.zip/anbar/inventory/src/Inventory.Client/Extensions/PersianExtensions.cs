using Inventory.Shared;

namespace Inventory.Client.Extensions;

public static class PersianExtensions
{
    /// <summary>تاریخ شمسی کوتاه: 1403/05/12</summary>
    public static string ToFa(this DateTime dt) => PersianDate.ToShort(dt);

    /// <summary>تاریخ شمسی بلند: ۱۲ مرداد ۱۴۰۳</summary>
    public static string ToFaLong(this DateTime dt) => PersianDate.ToLong(dt);

    /// <summary>تاریخ و ساعت شمسی</summary>
    public static string ToFaDateTime(this DateTime dt) => PersianDate.ToShortDateTime(dt);

    /// <summary>مبلغ با ارقام فارسی و جداکننده هزارگان</summary>
    public static string Money(this decimal v) => Fa.Money(v);

    /// <summary>عدد صحیح با ارقام فارسی</summary>
    public static string Num(this decimal v) => Fa.Number(v);

    public static string Num(this int v) => Fa.Number(v);
}
