using System;
#nullable enable
namespace Agent.Console;

public class AgentProgram
{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("=== ایجنت کنسولی شناسنامه سیستم ===");
        System.Console.WriteLine("در حال جمع‌آوری اطلاعات سخت‌افزار...");

        var info = new SystemInfoData
        {
            AgentId = "AGENT-001",
            Motherboard = GetMotherboard(),
            Cpu = GetCpu(),
            Ram = GetRam(),
            HardDisk = GetHardDisk(),
            Graphics = GetGraphics(),
            Monitor = GetMonitor(),
            OsName = Environment.OSVersion.ToString(),
            TotalRamGb = GetRamGb()
        };

        System.Console.WriteLine($"CPU: {info.Cpu}");
        System.Console.WriteLine($"RAM: {info.Ram} ({info.TotalRamGb} GB)");
        System.Console.WriteLine($"Motherboard: {info.Motherboard}");
        System.Console.WriteLine($"Hard Disk: {info.HardDisk}");
        System.Console.WriteLine($"Graphics: {info.Graphics}");
        System.Console.WriteLine($"Monitor: {info.Monitor}");
        System.Console.WriteLine("داده‌ها آماده ارسال به API انبار هستند.");
    }

    static string GetMotherboard() => "ASUS ROG STRIX Z790-E";
    static string GetCpu() => "Intel Core i9-13900K";
    static string GetRam() => "64 GB DDR5";
    static string GetHardDisk() => "Samsung 990 PRO 2TB NVMe";
    static string GetGraphics() => "NVIDIA GeForce RTX 4090";
    static string GetMonitor() => "LG 27GP850-B UltraGear 2K 165Hz";
    static int GetRamGb() => 64;
}

public class SystemInfoData
{
    public string AgentId { get; set; } = "";
    public string? Motherboard { get; set; }
    public string? Cpu { get; set; }
    public string? Ram { get; set; }
    public string? HardDisk { get; set; }
    public string? Graphics { get; set; }
    public string? Monitor { get; set; }
    public string? OsName { get; set; }
    public int TotalRamGb { get; set; }
}
