using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Api.Data;

namespace Inventory.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SystemInfoController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly Hubs.DashboardBroadcaster _dash;
    public SystemInfoController(AppDbContext db, Hubs.DashboardBroadcaster dash)
    {
        _db = db;
        _dash = dash;
    }

    // ================= مدل‌های کمکی =================

    public class DiffItem
    {
        public string Field { get; set; } = "";
        public string? Old { get; set; }
        public string? New { get; set; }
        public bool Changed { get; set; }
    }

    public class PendingPayload
    {
        public string? Motherboard { get; set; }
        public string? Cpu { get; set; }
        public string? Ram { get; set; }
        public string? HardDisk { get; set; }
        public string? Graphics { get; set; }
        public string? Monitor { get; set; }
        public string? OsName { get; set; }
        public int TotalRamGb { get; set; }
        public string? DetailsJson { get; set; }
    }

    private static readonly JsonSerializerOptions JOpt = new() { PropertyNameCaseInsensitive = true };

    // ================= دریافت ایجنت (upsert + مقایسه) =================

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] SystemInfo info)
    {
        info.ReceivedAt = DateTime.Now;
        var existing = await _db.SystemInfos.FirstOrDefaultAsync(x => x.AgentId == info.AgentId);
        if (existing != null)
        {
            var payload = JsonSerializer.Serialize(new PendingPayload
            {
                Motherboard = info.Motherboard, Cpu = info.Cpu, Ram = info.Ram,
                HardDisk = info.HardDisk, Graphics = info.Graphics, Monitor = info.Monitor,
                OsName = info.OsName, TotalRamGb = info.TotalRamGb, DetailsJson = info.DetailsJson
            }, JOpt);

            var diffs = await BuildDiffFromDbAsync(existing, payload);

            if (diffs.All(d => !d.Changed))
            {
                // بدون تغییر — فقط تازه‌سازی زمان دریافت
                existing.ReceivedAt = DateTime.Now;
                await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
                return Ok(new { id = existing.Id, agent = existing.AgentId, updated = true, unchanged = true });
            }

            // تغییر دارد — به‌صورت «در انتظار مقایسه و تایید» ذخیره می‌شود
            existing.PendingPayloadJson = payload;
            existing.PendingReceivedAt = DateTime.Now;
            existing.ReceivedAt = DateTime.Now;
            await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
            return Ok(new
            {
                id = existing.Id,
                agent = existing.AgentId,
                updated = true,
                unchanged = false,
                pendingChanges = diffs.Count(d => d.Changed),
                message = "تغییرات سخت‌افزار تشخیص داده شد — در برنامه در انتظار تایید است."
            });
        }

        _db.SystemInfos.Add(info);
        await _db.SaveChangesAsync();
        SyncComponents(info);
        await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
        return Ok(new { id = info.Id, agent = info.AgentId, updated = false, firstRegistration = true });
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        // لیست از جدول‌های قطعات می‌خواند (همان منبع صفحه‌ی جزئیات) — فیلدهای تخت فقط fallback
        var systems = await _db.SystemInfos.AsNoTracking().ToListAsync();
        var ids = systems.Select(s => s.Id).ToList();

        var cpus = await _db.SystemCpus.AsNoTracking().Where(c => ids.Contains(c.SystemInfoId)).ToListAsync();
        var rams = await _db.SystemRams.AsNoTracking().Where(r => ids.Contains(r.SystemInfoId)).ToListAsync();
        var boards = await _db.SystemBoards.AsNoTracking().Where(b => ids.Contains(b.SystemInfoId)).ToListAsync();
        var nets = await _db.SystemNetAdapters.AsNoTracking().Where(n => ids.Contains(n.SystemInfoId)).ToListAsync();

        var result = systems
            .OrderByDescending(s => s.ReceivedAt)
            .Select(s =>
            {
                var ramSum = rams.Where(r => r.SystemInfoId == s.Id).Sum(r => r.CapacityGb);
                return new
                {
                    s.Id, s.AgentId, s.IsApproved, s.ReceivedAt, s.UserId,
                    s.PendingPayloadJson,
                    Cpu = cpus.FirstOrDefault(c => c.SystemInfoId == s.Id)?.Name ?? s.Cpu,
                    TotalRamGb = ramSum > 0 ? ramSum : s.TotalRamGb,
                    Ram = ramSum > 0 ? $"{ramSum} GB — {rams.Count(r => r.SystemInfoId == s.Id)} ماژول" : s.Ram,
                    Motherboard = boards.FirstOrDefault(b => b.SystemInfoId == s.Id)?.Board ?? s.Motherboard,
                    Ip = nets.FirstOrDefault(n => n.SystemInfoId == s.Id && !string.IsNullOrEmpty(n.Ipv4))?.Ipv4 ?? "",
                    s.OsName
                };
            }).ToList();

        return Ok(result);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        return item == null ? NotFound() : Ok(item);
    }

    // ================= مقایسه (فرم دو ستونه) =================

    [HttpGet("changes/{id}")]
    public async Task<IActionResult> Changes(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound(new { message = "سیستم یافت نشد." });

        if (string.IsNullOrWhiteSpace(item.PendingPayloadJson))
            return Ok(new { hasPending = false, diffs = Array.Empty<DiffItem>() });

        var diffs = await BuildDiffFromDbAsync(item, item.PendingPayloadJson);
        return Ok(new
        {
            hasPending = true,
            pendingReceivedAt = item.PendingReceivedAt,
            changeCount = diffs.Count(d => d.Changed),
            diffs
        });
    }

    [HttpPost("apply/{id}")]
    public async Task<IActionResult> Apply(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound(new { message = "سیستم یافت نشد." });
        if (string.IsNullOrWhiteSpace(item.PendingPayloadJson))
            return BadRequest(new { message = "تغییر در انتظاری وجود ندارد." });

        var payload = JsonSerializer.Deserialize<PendingPayload>(item.PendingPayloadJson, JOpt);
        if (payload == null) return BadRequest(new { message = "داده‌ی در انتظار نامعتبر است." });

        var diffs = await BuildDiffFromDbAsync(item, item.PendingPayloadJson);

        // ۱) ثبت در تاریخچه
        _db.SystemInfoChangeLogs.Add(new SystemInfoChangeLog
        {
            SystemInfoId = item.Id,
            AgentId = item.AgentId,
            ChangedAt = DateTime.Now,
            ChangeCount = diffs.Count(d => d.Changed),
            ChangesJson = JsonSerializer.Serialize(diffs, JOpt)
        });

        // ۲) اعمال داده‌ی جدید
        item.Motherboard = payload.Motherboard;
        item.Cpu = payload.Cpu;
        item.Ram = payload.Ram;
        item.HardDisk = payload.HardDisk;
        item.Graphics = payload.Graphics;
        item.Monitor = payload.Monitor;
        item.OsName = payload.OsName;
        item.TotalRamGb = payload.TotalRamGb;
        item.DetailsJson = payload.DetailsJson;
        item.ReceivedAt = DateTime.Now;
        item.PendingPayloadJson = null;
        item.PendingReceivedAt = null;

        SyncComponents(item);
        await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
        return Ok(new { applied = true, changes = diffs.Count(d => d.Changed) });
    }

    [HttpPost("discard/{id}")]
    public async Task<IActionResult> Discard(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound(new { message = "سیستم یافت نشد." });
        item.PendingPayloadJson = null;
        item.PendingReceivedAt = null;
        await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
        return Ok(new { discarded = true });
    }

    // ================= تاریخچه =================

    public class HistoryEntry
    {
        public int Id { get; set; }
        public DateTime ChangedAt { get; set; }
        public int ChangeCount { get; set; }
        public List<DiffItem> Diffs { get; set; } = new();
    }

    [HttpGet("history/{id}")]
    public async Task<IActionResult> History(int id)
    {
        var logs = await _db.SystemInfoChangeLogs
            .Where(l => l.SystemInfoId == id)
            .OrderByDescending(l => l.ChangedAt)
            .ToListAsync();

        var result = logs.Select(l => new HistoryEntry
        {
            Id = l.Id,
            ChangedAt = l.ChangedAt,
            ChangeCount = l.ChangeCount,
            Diffs = TryParseDiffs(l.ChangesJson)
        }).ToList();

        return Ok(result);
    }

    private static List<DiffItem> TryParseDiffs(string json)
    {
        try { return JsonSerializer.Deserialize<List<DiffItem>>(json, JOpt) ?? new(); }
        catch { return new(); }
    }

    // ================= اختصاص کاربر =================

    [HttpPost("assign-user")]
    public async Task<IActionResult> AssignUser([FromBody] SystemInfoUserLink link)
    {
        var systemInfoId = link?.SystemInfoId ?? 0;
        var userId = link?.UserId ?? 0;

        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == systemInfoId);
        if (item == null) return NotFound(new { message = "سیستم یافت نشد." });

        var user = await _db.SystemUsers.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null) return NotFound(new { message = "کاربر یافت نشد." });

        item.UserId = user.Id;
        item.CompanyId = user.CompanyId ?? item.CompanyId;
        item.DepartmentId = user.DepartmentId;
        await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
        return Ok(new { linked = true, userId = user.Id, systemInfoId = item.Id });
    }

    [HttpPost("approve/{id}")]
    public async Task<IActionResult> Approve(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound();
        item.IsApproved = true;
        await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
        return Ok(new { id, approved = true });
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _db.SystemInfos.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound();
        RemoveComponents(item.Id);
        _db.SystemInfos.Remove(item);
        await _db.SaveChangesAsync();
        _ = _dash.BroadcastAsync();
        return Ok();
    }

    // ================= قطعات به تفکیک جدول‌های مجزا =================

    [HttpGet("{id}/components")]
    public async Task<IActionResult> Components(int id)
    {
        if (!await _db.SystemInfos.AnyAsync(x => x.Id == id))
            return NotFound(new { message = "سیستم یافت نشد." });

        return Ok(new
        {
            board = await _db.SystemBoards.AsNoTracking().Where(x => x.SystemInfoId == id).FirstOrDefaultAsync(),
            cpus = await _db.SystemCpus.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync(),
            rams = await _db.SystemRams.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync(),
            disks = await _db.SystemDisks.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync(),
            gpus = await _db.SystemGpus.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync(),
            monitors = await _db.SystemMonitors.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync(),
            netAdapters = await _db.SystemNetAdapters.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync(),
            volumes = await _db.SystemVolumes.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync()
        });
    }

    /// <summary>پر کردن جدول‌های قطعات از DetailsJson (حذف قبلی‌ها + درج جدید).</summary>
    private void SyncComponents(SystemInfo item)
    {
        RemoveComponents(item.Id);
        if (string.IsNullOrWhiteSpace(item.DetailsJson)) return;
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(item.DetailsJson);
            var root = doc.RootElement;

            var boardName = RootStr(root, "board");
            var boardSerial = RootStr(root, "boardSerial");
            var computerModel = RootStr(root, "computerModel");
            if (boardName.Length > 0 || boardSerial.Length > 0 || computerModel.Length > 0)
                _db.SystemBoards.Add(new SystemBoard { SystemInfoId = item.Id, Board = boardName, BoardSerial = boardSerial, ComputerModel = computerModel });

            foreach (var e in EnumArray(root, "cpus"))
                _db.SystemCpus.Add(new SystemCpu { SystemInfoId = item.Id, Name = Str(e, "name"), Cores = Int(e, "cores"), Threads = Int(e, "threads"), ClockGhz = Dbl(e, "clockGhz") });

            foreach (var e in EnumArray(root, "ramSticks"))
                _db.SystemRams.Add(new SystemRam { SystemInfoId = item.Id, Slot = Str(e, "slot"), CapacityGb = Int(e, "capacityGb"), Type = Str(e, "type"), SpeedMhz = Int(e, "speedMhz"), Manufacturer = Str(e, "manufacturer"), PartNumber = Str(e, "partNumber"), SerialNumber = Str(e, "serialNumber") });

            foreach (var e in EnumArray(root, "disks"))
                _db.SystemDisks.Add(new SystemDisk { SystemInfoId = item.Id, Model = Str(e, "model"), SizeGb = Int(e, "sizeGb"), Interface = Str(e, "interface"), SerialNumber = Str(e, "serialNumber") });

            foreach (var e in EnumArray(root, "gpus"))
                _db.SystemGpus.Add(new SystemGpu { SystemInfoId = item.Id, Name = Str(e, "name"), Resolution = Str(e, "resolution") });

            foreach (var e in EnumArray(root, "monitors"))
                _db.SystemMonitors.Add(new SystemMonitor { SystemInfoId = item.Id, Name = Str(e, "name"), Resolution = Str(e, "resolution"), SerialNumber = Str(e, "serialNumber"), IsPrimary = Bool(e, "isPrimary") });

            foreach (var e in EnumArray(root, "netAdapters"))
                _db.SystemNetAdapters.Add(new SystemNetAdapter { SystemInfoId = item.Id, Name = Str(e, "name"), Description = Str(e, "description"), Type = Str(e, "type"), MacAddress = Str(e, "macAddress"), Ipv4 = Str(e, "ipv4"), Gateway = Str(e, "gateway") });

            foreach (var e in EnumArray(root, "volumes"))
                _db.SystemVolumes.Add(new SystemVolume { SystemInfoId = item.Id, Letter = Str(e, "letter"), Label = Str(e, "label"), TotalGb = Int(e, "totalGb"), UsedGb = Int(e, "usedGb") });
        }
        catch { }
    }

    private void RemoveComponents(int systemInfoId)
    {
        _db.SystemBoards.RemoveRange(_db.SystemBoards.Where(x => x.SystemInfoId == systemInfoId));
        _db.SystemCpus.RemoveRange(_db.SystemCpus.Where(x => x.SystemInfoId == systemInfoId));
        _db.SystemRams.RemoveRange(_db.SystemRams.Where(x => x.SystemInfoId == systemInfoId));
        _db.SystemDisks.RemoveRange(_db.SystemDisks.Where(x => x.SystemInfoId == systemInfoId));
        _db.SystemGpus.RemoveRange(_db.SystemGpus.Where(x => x.SystemInfoId == systemInfoId));
        _db.SystemMonitors.RemoveRange(_db.SystemMonitors.Where(x => x.SystemInfoId == systemInfoId));
        _db.SystemNetAdapters.RemoveRange(_db.SystemNetAdapters.Where(x => x.SystemInfoId == systemInfoId));
        _db.SystemVolumes.RemoveRange(_db.SystemVolumes.Where(x => x.SystemInfoId == systemInfoId));
    }

    private static string RootStr(System.Text.Json.JsonElement root, string prop)
        => root.TryGetProperty(prop, out var v) && v.ValueKind == System.Text.Json.JsonValueKind.String ? (v.GetString() ?? "") : "";

    private static IEnumerable<System.Text.Json.JsonElement> EnumArray(System.Text.Json.JsonElement root, string prop)
    {
        if (root.TryGetProperty(prop, out var arr) && arr.ValueKind == System.Text.Json.JsonValueKind.Array)
            foreach (var e in arr.EnumerateArray())
                yield return e;
    }

    private static string Str(System.Text.Json.JsonElement e, string prop)
        => e.TryGetProperty(prop, out var v) && v.ValueKind == System.Text.Json.JsonValueKind.String ? (v.GetString() ?? "") : "";

    private static int Int(System.Text.Json.JsonElement e, string prop)
        => e.TryGetProperty(prop, out var v) && v.ValueKind == System.Text.Json.JsonValueKind.Number && v.TryGetInt32(out var i) ? i : 0;

    private static double Dbl(System.Text.Json.JsonElement e, string prop)
        => e.TryGetProperty(prop, out var v) && v.ValueKind == System.Text.Json.JsonValueKind.Number && v.TryGetDouble(out var d) ? d : 0;

    private static bool Bool(System.Text.Json.JsonElement e, string prop)
        => e.TryGetProperty(prop, out var v) && v.ValueKind == System.Text.Json.JsonValueKind.True;

    // ================= موتور مقایسه =================

    /// <summary>
    /// مقایسه‌ی واقعی با بانک اطلاعاتی: سمت «قدیم» مستقیماً از جدول‌های SQL قطعات خوانده می‌شود
    /// (SystemCpus/SystemRams/SystemDisks/...) و سمت «جدید» از داده‌ی ارسالی ایجنت.
    /// اگر جدول‌ها برای رکورد قدیمی خالی باشند، از DetailsJson به‌عنوان fallback استفاده می‌شود.
    /// </summary>
    private async Task<List<DiffItem>> BuildDiffFromDbAsync(SystemInfo current, string pendingPayloadJson)
    {
        var id = current.Id;
        var cpus = await _db.SystemCpus.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync();
        var rams = await _db.SystemRams.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync();
        var disks = await _db.SystemDisks.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync();
        var gpus = await _db.SystemGpus.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync();
        var monitors = await _db.SystemMonitors.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync();
        var nets = await _db.SystemNetAdapters.AsNoTracking().Where(x => x.SystemInfoId == id).ToListAsync();
        var board = await _db.SystemBoards.AsNoTracking().Where(x => x.SystemInfoId == id).FirstOrDefaultAsync();

        var hasTables = cpus.Count + rams.Count + disks.Count + gpus.Count + monitors.Count + nets.Count + (board != null ? 1 : 0) > 0;
        if (!hasTables) return BuildDiff(current, pendingPayloadJson); // رکورد قدیمی — مقایسه از JSON

        PendingPayload pending;
        try { pending = JsonSerializer.Deserialize<PendingPayload>(pendingPayloadJson, JOpt) ?? new PendingPayload(); }
        catch { pending = new PendingPayload(); }
        JsonDocument? newDoc = TryParse(pending.DetailsJson);

        var list = new List<DiffItem>();
        void Add(string field, string? oldV, string? newV)
        {
            oldV = Clean(oldV); newV = Clean(newV);
            list.Add(new DiffItem { Field = field, Old = oldV, New = newV, Changed = !string.Equals(oldV, newV, StringComparison.OrdinalIgnoreCase) });
        }

        Add("مادربرد", board?.Board, Arr(newDoc, "board", One));
        Add("سریال مادربرد", board?.BoardSerial, Arr(newDoc, "boardSerial", One));
        Add("مدل سیستم", board?.ComputerModel, Arr(newDoc, "computerModel", One));
        Add("پردازنده",
            cpus.Count > 0 ? string.Join(" + ", cpus.Select(c => c.Name)) : null,
            Joined(newDoc, "cpus", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? pending.Cpu);
        Add("رم",
            rams.Count > 0 ? string.Join(" + ", rams.Select(r => $"{r.CapacityGb}GB {r.Type}".Trim())) : null,
            Joined(newDoc, "ramSticks", e =>
            {
                var gb = e.TryGetProperty("capacityGb", out var g) ? g.GetInt32() : 0;
                var ty = e.TryGetProperty("type", out var t) ? t.GetString() : null;
                return $"{gb}GB {ty}".Trim();
            }) ?? pending.Ram);
        Add("هارد دیسک‌ها",
            disks.Count > 0 ? string.Join(" + ", disks.Select(d => $"{d.Model} ({d.SizeGb}GB)")) : null,
            Joined(newDoc, "disks", e =>
            {
                var m = e.TryGetProperty("model", out var x) ? x.GetString() : "";
                var gb = e.TryGetProperty("sizeGb", out var y) ? y.GetInt32() : 0;
                return $"{m} ({gb}GB)";
            }) ?? pending.HardDisk);
        Add("گرافیک",
            gpus.Count > 0 ? string.Join(" + ", gpus.Select(g => g.Name)) : null,
            Joined(newDoc, "gpus", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? pending.Graphics);
        Add("مانیتورها",
            monitors.Count > 0 ? string.Join(" + ", monitors.Select(m => m.Name)) : null,
            Joined(newDoc, "monitors", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? pending.Monitor);
        Add("کارت‌های شبکه",
            nets.Count > 0 ? string.Join(" + ", nets.Select(n => $"{n.Name} [{n.MacAddress}]")) : null,
            Joined(newDoc, "netAdapters", e =>
            {
                var n = e.TryGetProperty("name", out var x) ? x.GetString() : "";
                var m = e.TryGetProperty("macAddress", out var y) ? y.GetString() : "";
                return $"{n} [{m}]";
            }));
        Add("سیستم‌عامل", current.OsName, pending.OsName);

        newDoc?.Dispose();
        return list;
    }

    // ================= موتور مقایسه =================

    /// <summary>
    /// مقایسه‌ی اطلاعات فعلی سیستم با داده‌ی جدید ایجنت.
    /// فقط مشخصات شناسایی‌کننده‌ی سخت‌افزار مقایسه می‌شوند (حجم مصرفی درایو و IP به‌خاطر تغییر لحظه‌ای مقایسه نمی‌شوند).
    /// </summary>
    private static List<DiffItem> BuildDiff(SystemInfo current, string pendingPayloadJson)
    {
        PendingPayload pending;
        try { pending = JsonSerializer.Deserialize<PendingPayload>(pendingPayloadJson, JOpt) ?? new PendingPayload(); }
        catch { pending = new PendingPayload(); }

        JsonDocument? curDoc = TryParse(current.DetailsJson);
        JsonDocument? newDoc = TryParse(pending.DetailsJson);

        var list = new List<DiffItem>();

        void Add(string field, string? oldV, string? newV)
        {
            oldV = Clean(oldV);
            newV = Clean(newV);
            list.Add(new DiffItem
            {
                Field = field,
                Old = oldV,
                New = newV,
                Changed = !string.Equals(oldV, newV, StringComparison.OrdinalIgnoreCase)
            });
        }

        // ---- از DetailsJson ساختاریافته (با fallback روی فیلدهای تخت) ----
        Add("مادربرد", Arr(curDoc, "board", One), Arr(newDoc, "board", One) ?? pending.Motherboard);
        Add("مدل سیستم", Arr(curDoc, "computerModel", One), Arr(newDoc, "computerModel", One));
        Add("سریال مادربرد", Arr(curDoc, "boardSerial", One), Arr(newDoc, "boardSerial", One));

        Add("پردازنده",
            Joined(curDoc, "cpus", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? current.Cpu,
            Joined(newDoc, "cpus", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? pending.Cpu);

        Add("رم",
            Joined(curDoc, "ramSticks", e =>
            {
                var gb = e.TryGetProperty("capacityGb", out var g) ? g.GetInt32() : 0;
                var ty = e.TryGetProperty("type", out var t) ? t.GetString() : null;
                return $"{gb}GB {ty}".Trim();
            }) ?? current.Ram,
            Joined(newDoc, "ramSticks", e =>
            {
                var gb = e.TryGetProperty("capacityGb", out var g) ? g.GetInt32() : 0;
                var ty = e.TryGetProperty("type", out var t) ? t.GetString() : null;
                return $"{gb}GB {ty}".Trim();
            }) ?? pending.Ram);

        Add("هارد دیسک‌ها",
            Joined(curDoc, "disks", e =>
            {
                var m = e.TryGetProperty("model", out var x) ? x.GetString() : "";
                var gb = e.TryGetProperty("sizeGb", out var y) ? y.GetInt32() : 0;
                return $"{m} ({gb}GB)";
            }) ?? current.HardDisk,
            Joined(newDoc, "disks", e =>
            {
                var m = e.TryGetProperty("model", out var x) ? x.GetString() : "";
                var gb = e.TryGetProperty("sizeGb", out var y) ? y.GetInt32() : 0;
                return $"{m} ({gb}GB)";
            }) ?? pending.HardDisk);

        Add("گرافیک",
            Joined(curDoc, "gpus", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? current.Graphics,
            Joined(newDoc, "gpus", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? pending.Graphics);

        Add("مانیتورها",
            Joined(curDoc, "monitors", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? current.Monitor,
            Joined(newDoc, "monitors", e => e.TryGetProperty("name", out var n) ? n.GetString() : null) ?? pending.Monitor);

        // شبکه: نام + MAC (بدون IP — DHCP)
        Add("کارت‌های شبکه",
            Joined(curDoc, "netAdapters", e =>
            {
                var n = e.TryGetProperty("name", out var x) ? x.GetString() : "";
                var m = e.TryGetProperty("macAddress", out var y) ? y.GetString() : "";
                return $"{n} [{m}]";
            }),
            Joined(newDoc, "netAdapters", e =>
            {
                var n = e.TryGetProperty("name", out var x) ? x.GetString() : "";
                var m = e.TryGetProperty("macAddress", out var y) ? y.GetString() : "";
                return $"{n} [{m}]";
            }));

        Add("سیستم‌عامل", current.OsName, pending.OsName);

        curDoc?.Dispose();
        newDoc?.Dispose();
        return list;
    }

    private static string? Clean(string? s)
    {
        s = s?.Trim();
        return string.IsNullOrEmpty(s) ? null : s;
    }

    private static JsonDocument? TryParse(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        try { return JsonDocument.Parse(json); }
        catch { return null; }
    }

    private static string One(JsonElement e) => e.ValueKind == JsonValueKind.String ? (e.GetString() ?? "") : e.ToString();

    /// <summary>خواندن یک مقدار رشته‌ای مستقیم از JSON</summary>
    private static string? Arr(JsonDocument? doc, string prop, Func<JsonElement, string> fmt)
    {
        if (doc == null) return null;
        if (doc.RootElement.TryGetProperty(prop, out var el) && el.ValueKind != JsonValueKind.Null)
            return fmt(el);
        return null;
    }

    /// <summary>جمع‌بندی یک آرایه از اشیا به یک رشته (مثل: نام همه‌ی هاردها)</summary>
    private static string? Joined(JsonDocument? doc, string prop, Func<JsonElement, string?> fmt)
    {
        if (doc == null) return null;
        if (!doc.RootElement.TryGetProperty(prop, out var arr) || arr.ValueKind != JsonValueKind.Array) return null;
        var parts = arr.EnumerateArray().Select(fmt).Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s!.Trim());
        var joined = string.Join(" + ", parts);
        return joined.Length == 0 ? null : joined;
    }
}

public class SystemInfoUserLink
{
    public int SystemInfoId { get; set; }
    public int UserId { get; set; }
}
