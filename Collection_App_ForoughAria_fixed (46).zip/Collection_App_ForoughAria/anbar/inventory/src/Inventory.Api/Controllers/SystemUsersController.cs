using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory.Api.Data;

namespace Inventory.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SystemUsersController : ControllerBase
{
    private readonly AppDbContext _db;
    public SystemUsersController(AppDbContext db) => _db = db;

    [HttpGet] public async Task<ActionResult> Get() => Ok(await _db.SystemUsers.ToListAsync());
    [HttpGet("{id}")] public async Task<ActionResult> Get(int id) => Ok(await _db.SystemUsers.FirstOrDefaultAsync(x => x.Id == id));
    [HttpPost] public async Task<ActionResult> Post([FromBody] SystemUser u) { _db.SystemUsers.Add(u); await _db.SaveChangesAsync(); return Ok(new { id = u.Id }); }

    [HttpPut("{id}")]
    public async Task<ActionResult> Put(int id, [FromBody] SystemUser u)
    {
        var item = await _db.SystemUsers.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound();
        item.FirstName = u.FirstName;
        item.LastName = u.LastName;
        item.StaffNumber = u.StaffNumber;
        item.DepartmentId = u.DepartmentId;
        item.CompanyId = u.CompanyId;
        item.Role = u.Role;
        item.IsActive = u.IsActive;
        await _db.SaveChangesAsync();
        return Ok();
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var item = await _db.SystemUsers.FirstOrDefaultAsync(x => x.Id == id);
        if (item == null) return NotFound();
        _db.SystemUsers.Remove(item);
        await _db.SaveChangesAsync();
        return Ok();
    }
}
